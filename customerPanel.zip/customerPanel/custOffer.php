<?php 
$currentMainPage = "MyOffers";
include "customerHeader.php"; 
include "..\classes\EmailController.php";

?>
<?php include "customerFooter.php"; ?>